﻿Imports System.IO

Public Class Form1



    Dim importantNOTICE As String = "OY! YOU SHOULDN'T BE HERE YOU CUNT. YOUR IP HAS BEEN LOGGED"






    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If (e.CloseReason = CloseReason.UserClosing) Then
            e.Cancel = True
            Me.Hide()
            Label1.Text = ""
        End If
    End Sub

    Shared scanbox As String

    Dim second As Integer
    Public watchfolder As FileSystemWatcher
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'dev msg
        ' MsgBox("Ratno running in background.")
        Label1.Text = ""
        TextBox1.Text = ""
        Me.Hide()
        Me.WindowState = FormWindowState.Minimized
        Me.Visible = False


        ' Me.WindowState = FormWindowState.Minimized
        ' Me.Opacity = "100"
        Try
            My.Computer.Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", True).SetValue(Application.ProductName, Application.ExecutablePath)
        Catch ex As Exception
            Application.DoEvents()
        End Try

        CheckForIllegalCrossThreadCalls = False
        watchfolder = New System.IO.FileSystemWatcher()
        watchfolder.IncludeSubdirectories = True

        watchfolder.Path = "C:\"
        watchfolder.NotifyFilter = IO.NotifyFilters.DirectoryName
        watchfolder.NotifyFilter = watchfolder.NotifyFilter Or
                                   IO.NotifyFilters.FileName
        watchfolder.NotifyFilter = watchfolder.NotifyFilter Or
                                   IO.NotifyFilters.Attributes
        'adding a filter will not exlclude that extension but exclude every other extension apart from this one. Neet!
        watchfolder.Filter = "*.exe"
        '  watchfolder.Filter = "c:\Windows\"

        AddHandler watchfolder.Changed, AddressOf logchange
        AddHandler watchfolder.Created, AddressOf logchange
        AddHandler watchfolder.Deleted, AddressOf logchange
        ' AddHandler watchfolder.Renamed, AddressOf logrename
        watchfolder.EnableRaisingEvents = True
        Me.Visible = False

    End Sub


#Region "Position Form In Bottom Right Corner And Load Form"

    Public Sub showalert()








    End Sub

#End Region

#Region "Check And Create Directory And Whitelist"

    Dim path As String = "C:\Program Files\ratno-av\"
    Dim databasepath As String = path + "whitelist.txt"
    Public Sub checkit()

        If Not Directory.Exists(path) Then
            Directory.CreateDirectory(path)
            If Not System.IO.File.Exists(databasepath) Then
                System.IO.File.Create(databasepath).Dispose()
            Else
            End If
        Else
            If Not System.IO.File.Exists(databasepath) Then
                System.IO.File.Create(databasepath).Dispose()
            Else
            End If
        End If

    End Sub


#End Region

#Region "Scan File (Main Region)"

    Private Sub logchange(ByVal source As Object, ByVal e As _
                       System.IO.FileSystemEventArgs)
        If e.ChangeType = IO.WatcherChangeTypes.Changed Then



            scanbox = IO.File.ReadAllText(databasepath)
            If scanbox.Contains(e.FullPath) Then

            Else


                'results.action1.Text = "Ratno caught a file being modified."
                '   MsgBox(e.Name)
                '   MsgBox(e.FullPath)

                Dim lvi = New ListViewItem(e.FullPath)



                'results is another form with a listview (results form)
                ListView1.Items.Add(lvi)
                Label1.Text = e.FullPath

                'OLD FORMAT Results.Label3.Text = File

                Me.Opacity = "100"

                Timer1.Start() 'Timer starts functioning

                Me.Visible = True
                Dim x As Integer
                Dim y As Integer
                x = Screen.PrimaryScreen.WorkingArea.Width - Me.Width
                y = Screen.PrimaryScreen.WorkingArea.Height - Me.Height
                Me.Location = New Point(x, y)


            End If
        End If




        If e.ChangeType = IO.WatcherChangeTypes.Created Then
            ' MsgBox("detected")

            scanbox = IO.File.ReadAllText(databasepath)
            If scanbox.Contains(e.FullPath) Then
                'program is whitelisted!
            Else


                'results.action1.Text = "Ratno caught a file being modified."
                '   MsgBox(e.Name)
                '   MsgBox(e.FullPath)

                Dim lvi = New ListViewItem(e.FullPath)



                'results is another form with a listview (results form)
                ListView1.Items.Add(lvi)
                Label1.Text = e.FullPath

                'OLD FORMAT Results.Label3.Text = File
                Me.Opacity = "100"

                Timer1.Start() 'Timer starts functioning

                Dim x As Integer
                Dim y As Integer
                x = Screen.PrimaryScreen.WorkingArea.Width - Me.Width
                y = Screen.PrimaryScreen.WorkingArea.Height - Me.Height
                Me.Location = New Point(x, y)



            End If

        End If


        If e.ChangeType = IO.WatcherChangeTypes.Deleted Then



            scanbox = IO.File.ReadAllText(databasepath)
            If scanbox.Contains(e.FullPath) Then

            Else


                'results.action1.Text = "Ratno caught a file being modified."
                '   MsgBox(e.Name)
                '   MsgBox(e.FullPath)

                Dim lvi = New ListViewItem(e.FullPath)



                'results is another form with a listview (results form)
                '    ListView1.Items.Add(lvi)
                Label1.Text = e.FullPath



                '    Me.Opacity = "100"

                Dim x As Integer
                Dim y As Integer
                x = Screen.PrimaryScreen.WorkingArea.Width - Me.Width
                y = Screen.PrimaryScreen.WorkingArea.Height - Me.Height
                Me.Location = New Point(x, y)



            End If

        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked

        Try


            Dim path As String = "C:\Program Files\ratno-av\"
            Dim databasepath As String = path + "whitelist.txt"

            Dim file As System.IO.StreamWriter
            ' MsgBox(My.Application.Info.DirectoryPath + "/viruslist.txt")



            file = My.Computer.FileSystem.OpenTextFileWriter(databasepath, True)
            file.WriteLine(TextBox1.Text)
            file.Close()

            ListView1.Items.Clear()

            If ListView1.Items.Count = 0 Then

                Me.Opacity = "0"
            Else
                Me.Show()
                Me.Opacity = "100"
                TextBox1.Text = ""

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Try



            If TextBox1.Text = "" Then
                MsgBox("To remove items, please select an item from the table.")
            Else

                Try


                    IO.File.Delete(TextBox1.Text)
                    'ListView1.Items.Remove(ListView1.Items.Remove(listItem))
                    ListView1.Items.Clear()

                    If ListView1.Items.Count = 0 Then

                        Me.Opacity = "0"
                    Else
                        Me.Show()
                        Me.Opacity = "100"
                        TextBox1.Text = ""

                    End If
                Catch ex As Exception
                    MsgBox("Could not delete file. Try manual deletion")
                    Me.Opacity = "100"
                End Try

            End If

            ' Me.Opacity = "100"



        Catch ex As Exception
            '   action1.Text = "Unable to perform action. Process may be running."

            Me.Opacity = "0"
            Me.TopMost = True
            ListView1.Items.Clear()


        End Try



    End Sub



    Private Sub ListView1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView1.Click
        Try
            Label1.Text = ListView1.SelectedItems(0).Text
            TextBox1.Text = ListView1.SelectedItems(0).Text

        Catch ex As Exception
            'failed. try another method

            'OY! skid!

        End Try

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Me.Hide()
        Me.Opacity = "0"
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If Me.Opacity = "100" Then
            second = second + 1
            Label2.Text = second

            If second = 10 Then
                Timer1.Stop() 'Timer stops functioning
                Me.Opacity = "0"

            End If
        Else
            'Do nothing :)
        End If


    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        MsgBox("Please note that Ratno will not delete or suspend any caught items and is merely a tool used to identify unusual program movement. Ratno was designed for one purpose, stop Droppers and Rats. This tool is aimed at techie people and is NOT to be used without a secondary antivirus present.")
    End Sub



#End Region


End Class
