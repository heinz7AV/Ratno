﻿Imports System.Resources
Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Ratno File Protection")>
<Assembly: AssemblyDescription("Protect your files with our latest Ratno file protection security.")>
<Assembly: AssemblyCompany("Ratno Antivirus")>
<Assembly: AssemblyProduct("Ratno File Protection")>
<Assembly: AssemblyCopyright("Copyright © Ratno Antivirus 2018")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("7ccb35e7-26b0-4f66-b0a5-7ec37ef86be9")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.6.2.4")>
<Assembly: AssemblyFileVersion("4.1.4.2")>
<Assembly: NeutralResourcesLanguage("en-GB")>
